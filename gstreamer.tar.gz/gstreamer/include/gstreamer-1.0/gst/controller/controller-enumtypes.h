


#ifndef __GST_CONTROLLER_ENUM_TYPES_H__
#define __GST_CONTROLLER_ENUM_TYPES_H__

#include <glib-object.h>
#include <gst/gstconfig.h>
#include <gst/controller/controller-prelude.h>

G_BEGIN_DECLS

/* enumerations from "../subprojects/gstreamer/libs/gst/controller/gstinterpolationcontrolsource.h" */
GST_CONTROLLER_API
GType gst_interpolation_mode_get_type (void);
#define GST_TYPE_INTERPOLATION_MODE (gst_interpolation_mode_get_type())

/* enumerations from "../subprojects/gstreamer/libs/gst/controller/gstlfocontrolsource.h" */
GST_CONTROLLER_API
GType gst_lfo_waveform_get_type (void);
#define GST_TYPE_LFO_WAVEFORM (gst_lfo_waveform_get_type())
G_END_DECLS

#endif /* __GST_CONTROLLER_ENUM_TYPES_H__ */



